-- ============================================================================
-- Boundary — IPL Ticket Booking
-- Run this in your Supabase project's SQL editor (Database -> SQL Editor).
-- Assumes Supabase Auth is used for users (auth.users), so there is no
-- separate "users" table — profile info lives in a "profiles" table keyed
-- to auth.uid().
-- ============================================================================

-- ---------- profiles ----------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  created_at timestamptz not null default now()
);

alter table profiles enable row level security;

create policy "Users can view their own profile"
  on profiles for select using (auth.uid() = id);

create policy "Users can insert their own profile"
  on profiles for insert with check (auth.uid() = id);

create policy "Users can update their own profile"
  on profiles for update using (auth.uid() = id);

-- Auto-create a profile row whenever someone signs up.
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', 'IPL Fan'));
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ---------- matches ----------
create table if not exists matches (
  id uuid primary key default gen_random_uuid(),
  team_a text not null,
  team_b text not null,
  venue text not null,
  match_date date not null,
  match_time text not null,
  is_hot boolean not null default false,
  price_general numeric not null,
  price_premium numeric not null,
  price_vip numeric not null,
  created_at timestamptz not null default now()
);

alter table matches enable row level security;

create policy "Anyone can view matches"
  on matches for select using (true);
-- Insert/update/delete on matches is intentionally left to admins via the
-- Supabase dashboard/service role — no public write policy is defined.

-- ---------- seats ----------
-- One row per physical seat per match. Pre-generate rows for each match
-- (see seed section) so booking is a simple UPDATE, not a race-prone counter.
create table if not exists seats (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references matches(id) on delete cascade,
  tier text not null check (tier in ('general', 'premium', 'vip')),
  row_number int not null,
  seat_number int not null,
  status text not null default 'available' check (status in ('available', 'held', 'booked')),
  booking_id uuid references bookings(id) on delete set null,
  unique (match_id, tier, row_number, seat_number)
);

alter table seats enable row level security;

create policy "Anyone can view seats"
  on seats for select using (true);

-- ---------- bookings ----------
create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  match_id uuid not null references matches(id) on delete cascade,
  total_amount numeric not null,
  status text not null default 'confirmed' check (status in ('confirmed', 'cancelled')),
  created_at timestamptz not null default now()
);

alter table bookings enable row level security;

create policy "Users can view their own bookings"
  on bookings for select using (auth.uid() = user_id);

create policy "Users can create their own bookings"
  on bookings for insert with check (auth.uid() = user_id);

create policy "Users can cancel their own bookings"
  on bookings for update using (auth.uid() = user_id);

-- seats.booking_id references bookings, but bookings didn't exist yet when
-- seats was defined above — add the FK now that both tables exist.
alter table seats
  add constraint seats_booking_id_fkey
  foreign key (booking_id) references bookings(id) on delete set null;

-- Users may only update seats that belong to a booking they own (used when
-- booking: set status='booked', booking_id=<new booking>).
create policy "Users can book available seats"
  on seats for update using (
    status = 'available'
    or booking_id in (select id from bookings where user_id = auth.uid())
  );

-- ---------- seed matches ----------
insert into matches (team_a, team_b, venue, match_date, match_time, is_hot, price_general, price_premium, price_vip) values
  ('MI', 'CSK', 'Wankhede Stadium, Mumbai', '2026-04-12', '19:30', true, 1200, 3200, 8500),
  ('RCB', 'KKR', 'M. Chinnaswamy Stadium, Bengaluru', '2026-04-14', '19:30', true, 1000, 2800, 7500),
  ('GT', 'SRH', 'Narendra Modi Stadium, Ahmedabad', '2026-04-17', '15:30', false, 900, 2400, 6800),
  ('RR', 'PBKS', 'Sawai Mansingh Stadium, Jaipur', '2026-04-19', '19:30', false, 850, 2200, 6000);

-- ---------- seed seats (3 rows x 8 seats per tier per match) ----------
do $$
declare
  m record;
  tier_name text;
  r int;
  s int;
begin
  for m in select id from matches loop
    foreach tier_name in array array['general','premium','vip'] loop
      for r in 1..3 loop
        for s in 1..8 loop
          insert into seats (match_id, tier, row_number, seat_number)
          values (m.id, tier_name, r, s);
        end loop;
      end loop;
    end loop;
  end loop;
end $$;
