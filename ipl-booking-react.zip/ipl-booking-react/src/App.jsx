import { Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './lib/AuthContext'
import MatchList from './components/MatchList'
import SeatMap from './components/SeatMap'
import MyBookings from './components/MyBookings'
import AuthModal from './components/AuthModal'
import { useState } from 'react'

function Header() {
  const { user, signOut } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()
  const [authOpen, setAuthOpen] = useState(false)

  return (
    <header className="site">
      <div className="brand">
        <div className="brand-mark">B</div>
        <div className="brand-name">
          Boundary
          <span className="sub">IPL TICKET BOOKING</span>
        </div>
      </div>

      <nav className="tabs">
        <button className={location.pathname === '/' ? 'active' : ''} onClick={() => navigate('/')}>
          Fixtures
        </button>
        <button
          className={location.pathname === '/bookings' ? 'active' : ''}
          onClick={() => navigate('/bookings')}
        >
          My Bookings
        </button>
      </nav>

      <div className="auth-area">
        {user ? (
          <>
            <span className="user-chip">
              Signed in as <b>{user.user_metadata?.full_name || user.email}</b>
            </span>
            <button className="btn btn-ghost" onClick={signOut}>
              Log out
            </button>
          </>
        ) : (
          <>
            <button className="btn btn-ghost" onClick={() => setAuthOpen(true)}>
              Log in
            </button>
            <button className="btn btn-primary" onClick={() => setAuthOpen(true)}>
              Sign up
            </button>
          </>
        )}
      </div>

      {authOpen && <AuthModal onClose={() => setAuthOpen(false)} />}
    </header>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<MatchList />} />
          <Route path="/match/:matchId" element={<SeatMap />} />
          <Route path="/bookings" element={<MyBookings />} />
        </Routes>
      </main>
      <footer>
        Boundary IPL Ticket Booking — Capstone project. Built with React + Supabase, deployed on Vercel.
      </footer>
    </AuthProvider>
  )
}
