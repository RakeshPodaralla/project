import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../lib/AuthContext'

const TEAM_NAMES = {
  MI: 'Mumbai Indians',
  CSK: 'Chennai Super Kings',
  RCB: 'Royal Challengers',
  KKR: 'Kolkata Knight Riders',
  GT: 'Gujarat Titans',
  SRH: 'Sunrisers Hyderabad',
  RR: 'Rajasthan Royals',
  PBKS: 'Punjab Kings',
}

const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN')
const dateFmt = (d) =>
  new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })

export default function MatchList() {
  const [matches, setMatches] = useState([])
  const [openSeatCounts, setOpenSeatCounts] = useState({})
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()
  const { user } = useAuth()

  useEffect(() => {
    async function load() {
      setLoading(true)
      const { data: matchData, error } = await supabase
        .from('matches')
        .select('*')
        .order('match_date', { ascending: true })

      if (error) {
        console.error(error)
        setLoading(false)
        return
      }
      setMatches(matchData || [])

      // Count available seats per match for the "N left" badge.
      const { data: seatData } = await supabase.from('seats').select('match_id, status')
      const counts = {}
      ;(seatData || []).forEach((s) => {
        if (s.status === 'available') counts[s.match_id] = (counts[s.match_id] || 0) + 1
      })
      setOpenSeatCounts(counts)
      setLoading(false)
    }
    load()
  }, [])

  function handleSelect(matchId) {
    if (!user) {
      alert('Please log in to book seats.')
      return
    }
    navigate(`/match/${matchId}`)
  }

  return (
    <section>
      <div className="hero">
        <div>
          <div className="eyebrow">● SEASON 2026 — NOW BOOKING</div>
          <h1>
            Every seat has
            <br />
            a <em>story</em> to tell.
          </h1>
          <p>
            Book verified seats for every IPL fixture this season. Pick your tier, choose your exact seat in the
            stand, and walk in with a confirmed ticket.
          </p>
        </div>
      </div>

      <div className="section-head">
        <h2>Upcoming Fixtures</h2>
        <div className="count">{matches.length} fixtures</div>
      </div>

      {loading && <div className="summary-empty">Loading fixtures…</div>}

      <div className="matches-grid">
        {matches.map((m) => {
          const open = openSeatCounts[m.id] ?? 0
          const floor = Math.min(m.price_general, m.price_premium, m.price_vip)
          return (
            <div className="ticket" key={m.id}>
              <div className="venue-row">
                <div className="venue">{m.venue}</div>
                <div className={`tag ${m.is_hot ? 'hot' : 'open'}`}>
                  {m.is_hot ? 'IN DEMAND' : `${open} LEFT`}
                </div>
              </div>
              <div className="fixture">
                <div className="team">
                  <div className="badge">{m.team_a}</div>
                  <div className="name">{TEAM_NAMES[m.team_a] || m.team_a}</div>
                </div>
                <div className="vs">VS</div>
                <div className="team">
                  <div className="badge">{m.team_b}</div>
                  <div className="name">{TEAM_NAMES[m.team_b] || m.team_b}</div>
                </div>
              </div>
              <div className="meta-row">
                <span>{dateFmt(m.match_date)}</span>
                <span className="mono">{m.match_time} IST</span>
              </div>
              <div className="ticket-foot">
                <div className="from-price">
                  FROM <b>{fmt(floor)}</b>
                </div>
                <button className="btn btn-primary" onClick={() => handleSelect(m.id)}>
                  Select Seats
                </button>
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}
