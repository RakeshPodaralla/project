import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../lib/AuthContext'

const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN')
const dateFmt = (d) =>
  new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })

export default function MyBookings() {
  const { user } = useAuth()
  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(true)

  async function load() {
    if (!user) {
      setBookings([])
      setLoading(false)
      return
    }
    setLoading(true)
    // Pull bookings with their match info and the seats linked to each booking.
    const { data, error } = await supabase
      .from('bookings')
      .select('*, matches(*), seats(*)')
      .eq('user_id', user.id)
      .eq('status', 'confirmed')
      .order('created_at', { ascending: false })

    if (error) console.error(error)
    setBookings(data || [])
    setLoading(false)
  }

  useEffect(() => {
    load()
  }, [user])

  async function handleCancel(booking) {
    if (!confirm('Cancel this booking and release the seats?')) return

    // Release the seats first, then mark the booking cancelled.
    const { error: seatError } = await supabase
      .from('seats')
      .update({ status: 'available', booking_id: null })
      .eq('booking_id', booking.id)
    if (seatError) {
      alert(seatError.message)
      return
    }

    const { error: bookingError } = await supabase
      .from('bookings')
      .update({ status: 'cancelled' })
      .eq('id', booking.id)
    if (bookingError) {
      alert(bookingError.message)
      return
    }

    load()
  }

  if (!user) {
    return (
      <div className="empty-state">
        <div className="glyph">🔒</div>
        <div>Log in to see your bookings.</div>
      </div>
    )
  }

  return (
    <section>
      <div className="section-head">
        <h2>My Bookings</h2>
        <div className="count">
          {bookings.length} booking{bookings.length === 1 ? '' : 's'}
        </div>
      </div>

      {loading && <div className="summary-empty">Loading your bookings…</div>}

      {!loading && bookings.length === 0 && (
        <div className="empty-state">
          <div className="glyph">🎟</div>
          <div>No bookings yet — go grab some seats.</div>
        </div>
      )}

      {bookings.map((b) => (
        <div className="booking-item" key={b.id}>
          <div>
            <span className="status-pill confirmed">CONFIRMED</span>
            <div className="fx">
              {b.matches.team_a} vs {b.matches.team_b}
            </div>
            <div className="meta">
              <span>{b.matches.venue}</span>
              <span className="mono">
                {dateFmt(b.matches.match_date)} · {b.matches.match_time}
              </span>
              <span>
                {b.seats.length} seat{b.seats.length === 1 ? '' : 's'}
              </span>
            </div>
            <div className="seats-list">
              {b.seats.map((s) => `${s.tier} R${s.row_number}S${s.seat_number}`).join('  ·  ')}
            </div>
          </div>
          <div>
            <div className="price">{fmt(b.total_amount)}</div>
            <button className="btn btn-danger" style={{ marginTop: 8, width: '100%' }} onClick={() => handleCancel(b)}>
              Cancel
            </button>
          </div>
        </div>
      ))}
    </section>
  )
}
