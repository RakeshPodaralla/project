import { useEffect, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../lib/AuthContext'

const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN')
const dateFmt = (d) =>
  new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })

const TIER_META = {
  vip: { label: 'VIP Box', cls: 'vip' },
  premium: { label: 'Premium', cls: 'prem' },
  general: { label: 'General', cls: 'gen' },
}

export default function SeatMap() {
  const { matchId } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()

  const [match, setMatch] = useState(null)
  const [seats, setSeats] = useState([])
  const [selected, setSelected] = useState([])
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    async function load() {
      const { data: matchData } = await supabase.from('matches').select('*').eq('id', matchId).single()
      setMatch(matchData)

      const { data: seatData } = await supabase
        .from('seats')
        .select('*')
        .eq('match_id', matchId)
        .order('tier')
        .order('row_number')
        .order('seat_number')
      setSeats(seatData || [])
    }
    load()
  }, [matchId])

  function toggleSeat(seat) {
    if (seat.status !== 'available') return
    const isSelected = selected.some((s) => s.id === seat.id)
    if (isSelected) {
      setSelected(selected.filter((s) => s.id !== seat.id))
    } else {
      if (selected.length >= 8) {
        alert('You can select up to 8 seats per booking.')
        return
      }
      setSelected([...selected, seat])
    }
  }

  function priceFor(tier) {
    if (!match) return 0
    if (tier === 'vip') return match.price_vip
    if (tier === 'premium') return match.price_premium
    return match.price_general
  }

  const total = selected.reduce((sum, s) => sum + priceFor(s.tier), 0)

  async function handleConfirm() {
    if (!user) {
      alert('Please log in to confirm your booking.')
      return
    }
    if (selected.length === 0) return

    setSubmitting(true)
    try {
      // 1. Create the booking row.
      const { data: booking, error: bookingError } = await supabase
        .from('bookings')
        .insert({ user_id: user.id, match_id: matchId, total_amount: total, status: 'confirmed' })
        .select()
        .single()
      if (bookingError) throw bookingError

      // 2. Mark each selected seat as booked and link it to the booking.
      //    RLS policy "Users can book available seats" only allows this
      //    update while status is still 'available', which limits (but does
      //    not fully eliminate) double-booking races — a Postgres function
      //    with row locking is the hardened version for production.
      const seatIds = selected.map((s) => s.id)
      const { error: seatError } = await supabase
        .from('seats')
        .update({ status: 'booked', booking_id: booking.id })
        .in('id', seatIds)
        .eq('status', 'available')
      if (seatError) throw seatError

      alert(`Booked ${selected.length} seat(s) for ${fmt(total)}!`)
      navigate('/bookings')
    } catch (err) {
      alert(err.message || 'Booking failed. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  if (!match) return <div className="summary-empty">Loading fixture…</div>

  const tiers = ['vip', 'premium', 'general']

  return (
    <section>
      <div className="booking-header">
        <Link to="/" className="back-link">
          ← Back to fixtures
        </Link>
      </div>
      <h2 className="booking-header" style={{ marginTop: 2 }}>
        {match.team_a} vs {match.team_b}
      </h2>
      <div className="booking-sub">
        {match.venue} · {dateFmt(match.match_date)} · {match.match_time} IST
      </div>

      <div className="booking-layout">
        <div className="stadium-wrap">
          <div className="field-label">▾ PITCH THIS WAY ▾</div>

          {tiers.map((tierKey) => {
            const meta = TIER_META[tierKey]
            const tierSeats = seats.filter((s) => s.tier === tierKey)
            const rows = [...new Set(tierSeats.map((s) => s.row_number))].sort()
            return (
              <div className="bowl-tier" key={tierKey}>
                <div className="bowl-tier-label">
                  <span className="name">{meta.label}</span>
                  <span className="price">{fmt(priceFor(tierKey))} / seat</span>
                </div>
                {rows.map((rowNum) => {
                  const rowSeats = tierSeats.filter((s) => s.row_number === rowNum)
                  const mid = (rowSeats.length - 1) / 2
                  return (
                    <div className="arc-row" key={rowNum}>
                      {rowSeats.map((seat, idx) => {
                        const isSelected = selected.some((s) => s.id === seat.id)
                        const isSold = seat.status !== 'available'
                        const offset = Math.round(Math.abs(idx - mid) * 3.2)
                        return (
                          <button
                            key={seat.id}
                            className={`seat ${meta.cls} ${isSold ? 'sold' : isSelected ? 'selected' : 'avail'}`}
                            style={{ marginTop: offset }}
                            disabled={isSold}
                            title={`${meta.label} · Row ${rowNum} · Seat ${seat.seat_number} · ${fmt(priceFor(tierKey))}`}
                            onClick={() => toggleSeat(seat)}
                          >
                            {seat.seat_number}
                          </button>
                        )
                      })}
                    </div>
                  )
                })}
              </div>
            )
          })}

          <div className="legend">
            <div>
              <span className="sw" style={{ background: 'var(--saffron)' }}></span>VIP
            </div>
            <div>
              <span className="sw" style={{ background: 'var(--gold)' }}></span>Premium
            </div>
            <div>
              <span className="sw" style={{ background: 'var(--pitch)' }}></span>General
            </div>
            <div>
              <span className="sw" style={{ background: 'var(--night-3)' }}></span>Sold
            </div>
          </div>
        </div>

        <div className="summary-card">
          <h3>Your Selection</h3>
          {selected.length === 0 ? (
            <div className="summary-empty">Tap seats on the map to add them here.</div>
          ) : (
            <>
              {selected.map((s) => (
                <div className="summary-line" key={s.id}>
                  <div>
                    <div>{TIER_META[s.tier].label}</div>
                    <div className="seat-id">
                      Row {s.row_number} · Seat {s.seat_number}
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span className="mono">{fmt(priceFor(s.tier))}</span>
                    <button onClick={() => toggleSeat(s)}>✕</button>
                  </div>
                </div>
              ))}
              <div className="summary-total">
                <span>Total</span>
                <b>{fmt(total)}</b>
              </div>
            </>
          )}
          <button
            className="btn btn-primary"
            style={{ width: '100%', marginTop: 14 }}
            disabled={selected.length === 0 || submitting}
            onClick={handleConfirm}
          >
            {submitting ? 'Confirming…' : 'Confirm Booking'}
          </button>
        </div>
      </div>
    </section>
  )
}
