# Boundary — IPL Ticket Booking (Capstone)

A full-stack IPL ticket booking app: React (Vite) frontend, Supabase for
Postgres + Auth + CRUD, deployed on Vercel.

## Stack

- **Frontend:** React 18 + Vite, React Router
- **Backend:** Supabase (Postgres, Auth, Row Level Security)
- **Hosting:** Vercel

## Project structure

```
src/
  lib/
    supabaseClient.js   # Supabase client init (reads .env)
    AuthContext.jsx      # signUp / signIn / signOut, current user
  components/
    AuthModal.jsx         # login / signup form
    MatchList.jsx          # fixtures grid (reads `matches`, `seats`)
    SeatMap.jsx              # stadium seat picker + booking (writes `bookings`, `seats`)
    MyBookings.jsx            # booking history + cancel (reads/writes `bookings`, `seats`)
  App.jsx, main.jsx, index.css
supabase-schema.sql   # run this in Supabase's SQL editor before anything else
```

## 1. Create the Supabase project

1. Go to [supabase.com](https://supabase.com) → New project.
2. Once it's up, open **SQL Editor** and run the entire contents of
   `supabase-schema.sql`. This creates:
   - `profiles` (auto-created on signup via a trigger)
   - `matches` (seeded with 4 sample fixtures)
   - `seats` (auto-generated: 3 rows × 8 seats × 3 tiers, per match)
   - `bookings`
   - Row Level Security policies so users can only see/cancel their own bookings
3. Go to **Authentication → Providers** and make sure **Email** is enabled.
   For a classroom demo, you can turn off "Confirm email" under
   **Authentication → Settings** so signups work immediately without an
   inbox check.
4. Go to **Project Settings → API** and copy the **Project URL** and
   **anon public key** — you'll need both next.

## 2. Run it locally

```bash
npm install
cp .env.example .env
# paste your Supabase URL + anon key into .env
npm run dev
```

Open the printed local URL. Sign up, browse fixtures, pick seats on the
stadium map, confirm a booking, then check **My Bookings**.

## 3. Deploy to Vercel

1. Push this project to a GitHub repo.
2. Go to [vercel.com](https://vercel.com) → **Add New → Project** → import
   the repo.
3. Vercel auto-detects Vite. Before deploying, add environment variables
   under **Settings → Environment Variables**:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy. Every push to your main branch redeploys automatically.

## How the pieces map to the capstone stages

| Stage | Where it lives |
|---|---|
| Semantic HTML/CSS | `index.css` + JSX markup structure in each component |
| JS interaction & validation | `AuthModal.jsx` (email/password checks), `SeatMap.jsx` (seat toggling, 8-seat cap) |
| React | Whole `src/` — components, routing, state |
| Supabase CRUD | `MatchList` (read), `SeatMap` (insert booking, update seats), `MyBookings` (read, update/cancel) |
| Supabase Auth | `AuthContext.jsx`, `AuthModal.jsx` |
| Vercel deployment | Steps above |

## Notes / things to harden for a real production version

- Seat booking currently does an `UPDATE ... WHERE status = 'available'`
  from the client, which is fine for a classroom demo but still has a
  narrow race window under real concurrent traffic. The production fix is
  a Postgres function (`SECURITY DEFINER`) that does the seat-status check
  and booking insert in one transaction with row locking.
- Admin actions (adding matches, changing prices) aren't built into the UI —
  do them from the Supabase Table Editor, or add an `is_admin` flag on
  `profiles` and a small admin screen if your rubric requires it.
